package nl.isld.databees.task;

import nl.isld.databees.LocalStore;
import nl.isld.databees.R;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

public class TaskActivity extends FragmentActivity
	implements TextWatcher {
	
	public static final int			REQUEST_NEW_TASK		= 100;
	public static final int			REQUEST_EDIT_TASK		= 101;
	public static final String		RESULT_EXTRA_TASK_ID	= "RESULT_EXTRA_APIARY_ID";

	private Task					task;
	private EditText				tasktitle;
	
	
	/*
	 * Overridden method of class FragmentActivity.
	 * Creates the NewApiaryActivity activity.
	 * @see android.support.v4.app.FragmentActivity#onCreate(android.os.Bundle)
	 */
	@Override
    public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_task);
		
		initAttributes();
		initListeners();
	}
	
	/*
	 * Overridden method of class FragmentActivity.
	 * Creates the options menu for the NewApiaryActivity activity.
	 * @see android.app.Activity#onCreateOptionsMenu(android.view.Menu)
	 
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	    getMenuInflater().inflate(R.menu.activity_apiary_actions, menu);
	    return true;
	}
	*/
	
	/*
	 * Overridden method of class FragmentActivity.
	 * Called when an item in the options menu is selected.
	 * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
	 
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if(checkRequired()) {
			switch(item.getItemId()) {
			case R.id.action_save:	finish();
									return true;
			}
		}
		return false;
	}
	*/
	
	
	/*
	 * Overridden method of interface TextWatcher.
	 * @see android.text.TextWatcher#beforeTextChanged(java.lang.CharSequence, int, int, int)
	 */
	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// Nothing to be done
	}

	/*
	 * Overridden method of interface TextWatcher.
	 * @see android.text.TextWatcher#onTextChanged(java.lang.CharSequence, int, int, int)
	 */
	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		// Nothing to be done
	}
	
	
	
	
	@Override
	public void startActivityForResult(Intent intent, int requestCode) {
		intent.putExtra("REQUEST_CODE", requestCode);
		super.startActivityForResult(intent, requestCode);
	}

	
	/*
	 * Saves the apiary to the store and finishes the activity.
	 * Note that is should always be called after a call to
	 * checkRequired() and only if the latter returns true.
	 */
	@Override
	public void finish() {
		
		if(getIntent().getIntExtra("REQUEST_CODE", 0)
				== REQUEST_NEW_TASK) {
			LocalStore.TASK_LIST.add(task);
		}
		
		Intent intent = new Intent();
		intent.putExtra(RESULT_EXTRA_TASK_ID, task.getID());
		setResult(RESULT_OK, intent);
		
		super.finish();
	}
	
	/*
	 * Sets the values of all attributes.
	 */
	private void initAttributes() {
		task = new Task();
		tasktitle = (EditText) getActionBar().getCustomView().findViewById(R.id.editText1);
	}
	
	/*
	 * Sets up the listeners.
	 */
	private void initListeners() {
		tasktitle.addTextChangedListener(this);
	}

	@Override
	public void afterTextChanged(Editable s) {
		// TODO Auto-generated method stub
		
	}

	
	


}
