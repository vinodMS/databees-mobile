package nl.isld.databees.task;

import java.sql.Date;

public class Task {

    private String ID;
    private String title;
    private String desc;
    private Date deadLine, alarmDate;
    
    Task() {
    	this.title = new String();
    	this.desc = new String();
    }
    
    public Task(String title, String description) {
    	this.title = title;
    	this.desc = description;
    }
		
	public String getID() {
		return ID;	
	}
	
	public String getDescription() {
		return desc ;
	}
	
	public Date getDeadLine() {
		return deadLine ;
	}
	
	public boolean isAlarmOn() {
		return false;
	}
	
	public Date getAlarmDate() {
		return alarmDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
}
